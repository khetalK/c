#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int i = 1; i <= 9; i++) {
    if (i == 5) {
      continue;
    } else {
      {
        for (int j = 0; j < abs(i - 5) % 5; j++) {
          printf(".");
        }
      }

      {
        if (i <= 4) {
          printf("/");
        } else {
          printf("\\");
        }
      }

      {
        for (int j = 0; j < abs(i - 7) % 7; j += 2) {
          printf(".");
        }
      }

      printf("\n");
    }
  }

  return 0;
}
