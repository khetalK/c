#include <stdio.h>
#include <stdlib.h>

void alphabetPrinter() {
  int i = 1;
  while (i <= 4) {
    for (int j = 0; j < i; j++) {
      printf("%c ", 65 + j);
    }
    printf("\n");
    i++;
  }
}

void oneOOnePrinter() {
  int i = 0;
  while (i < 4) {

    int j = 0;
    while (j < 4 - i) {
      printf("%d ", 4 - j);
      j++;
    }

    printf("\n");
    i++;
  }
}

int main() {
  alphabetPrinter();
  printf("\n");
  oneOOnePrinter();
  return 0;
}
